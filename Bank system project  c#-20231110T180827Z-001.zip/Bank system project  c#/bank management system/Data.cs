﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp2
{
   public class Data
    {
        public static int LoginUserId { get; set; }
    }
}
