﻿using System;
using System.Collections.Generic;
using System.IO;

namespace WinFormsApp2
{
    public class Account
    {
        
        public int Id{ set; get; }
        public string Name { set; get; }
        public string Address { set; get; }
        public string Phone { set; get; }
        public string password { set; get; }
        public string UserName { set; get; }
        public string Date_of_birth { set; get; }
        public string Branche { set; get; }
        public string Gender { set; get; }
        public string Account_type { set; get; }
        public decimal Balance { set; get; }
        public string Occupation { set; get; }
       // public  Guid  Account_number { set; get; }
      

    }
}
