﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp2
{
    public class Complaint
    {
        public int Id { set; get; }
        public string ReceiveComplaint { set; get; }
    }
}
