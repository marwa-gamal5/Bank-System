﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectfinal
{
    public partial class Form_recieve_complaint : Form
    {
        public Form_recieve_complaint()
        {
            InitializeComponent();
        }

        private void complaint_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}
